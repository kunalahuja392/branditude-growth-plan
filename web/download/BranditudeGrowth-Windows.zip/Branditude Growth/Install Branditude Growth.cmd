@echo off
title Branditude Growth - Install
echo.
echo  Installing Branditude Growth for this Windows user...
echo  (No admin rights needed. Nothing else on your PC is changed.)
echo.
set "DIR=%LOCALAPPDATA%\BranditudeGrowth"
if not exist "%DIR%" mkdir "%DIR%"
copy /Y "%~dp0branditude.ico" "%DIR%\branditude.ico" >nul
copy /Y "%~dp0Uninstall Branditude Growth.cmd" "%DIR%\Uninstall.cmd" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$url='https://scale.branditudeglobal.com/app.html';" ^
  "$b=$null; foreach($k in 'msedge.exe','chrome.exe'){ foreach($h in 'HKCU','HKLM'){ $p=(Get-ItemProperty -Path ($h+':\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\'+$k) -ErrorAction SilentlyContinue).'(default)'; if($p -and (Test-Path $p)){ $b=$p; break } }; if($b){break} };" ^
  "if(-not $b){ $c=\"${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe\"; if(Test-Path $c){$b=$c} };" ^
  "if(-not $b){ Write-Host ' Could not find Microsoft Edge or Google Chrome. Please install one and run this again.'; exit 1 };" ^
  "$ws=New-Object -ComObject WScript.Shell;" ^
  "foreach($f in @([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Desktop'))){ $s=$ws.CreateShortcut((Join-Path $f 'Branditude Growth.lnk')); $s.TargetPath=$b; $s.Arguments='--app='+$url; $s.IconLocation=\"$env:LOCALAPPDATA\BranditudeGrowth\branditude.ico\"; $s.Description='Branditude Growth Plan'; $s.Save() };" ^
  "Write-Host ' Done. Branditude Growth is on your Desktop and in the Start menu.'"
if errorlevel 1 (pause & exit /b 1)
echo.
start "" "%USERPROFILE%\Desktop\Branditude Growth.lnk" 2>nul
pause
