@echo off
title Branditude Growth - Uninstall
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "foreach($f in @([Environment]::GetFolderPath('Programs'),[Environment]::GetFolderPath('Desktop'))){ Remove-Item (Join-Path $f 'Branditude Growth.lnk') -ErrorAction SilentlyContinue }"
echo  Branditude Growth shortcuts removed. Your account and data are not affected.
pause
rmdir /S /Q "%LOCALAPPDATA%\BranditudeGrowth" 2>nul
