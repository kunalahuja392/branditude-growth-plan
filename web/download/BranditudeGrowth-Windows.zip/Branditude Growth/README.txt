Branditude Growth for Windows
=============================

1. Right-click this zip and choose "Extract All".
2. Double-click "Install Branditude Growth.cmd".
   If Windows shows "Windows protected your PC", click "More info" then "Run anyway".
3. Branditude Growth opens in its own window. You'll find it on your Desktop
   and in the Start menu. Sign in with your usual email and password.

The app runs on Microsoft Edge or Google Chrome (already on most PCs).
To remove it, run "Uninstall Branditude Growth.cmd".

Help: WhatsApp Branditude, or visit https://scale.branditudeglobal.com
